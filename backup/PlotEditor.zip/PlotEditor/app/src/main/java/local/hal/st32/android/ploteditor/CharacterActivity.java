package local.hal.st32.android.ploteditor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TextView;

public class CharacterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character);
//
//        TextView tvRowAge = findViewById(R.id.tvRowAge);
//        //tvRowAge.setBackgroundColor(Color.GRAY);
//
//        TableLayout tvOutline = findViewById(R.id.tlOutline);



    }
}
